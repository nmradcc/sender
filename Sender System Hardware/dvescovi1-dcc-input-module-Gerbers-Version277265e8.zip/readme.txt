Project Name: DCC Input Module
Project Version: #277265e8
Project Url: https://www.flux.ai/dvescovi1/dcc-input-module~b0

Project Description:
Through-hole DCC input module schematic. Eight TLP240A DIP4 photorelays, 12-position decoder terminal and 2x5 IDC interface. Future PCB target approximately 3 x 2 inches; layout not started.


Index:

Bottom Copper (Gerber): dcc-input-module-b_cu.gbr
Bottom Solder Mask (Gerber): dcc-input-module-b_mask.gbr
Bottom Solder Paste (Gerber): dcc-input-module-b_paste.gbr
Bottom Silkscreen (Gerber): dcc-input-module-b_silks.gbr
Board Outline (Gerber): dcc-input-module-edge_cuts.gbr
Top Copper (Gerber): dcc-input-module-f_cu.gbr
Top Solder Mask (Gerber): dcc-input-module-f_mask.gbr
Top Solder Paste (Gerber): dcc-input-module-f_paste.gbr
Top Silkscreen (Gerber): dcc-input-module-f_silks.gbr
Drill Holes (Excellon): dcc-input-module.drl
Electrical Test Netlist (IPC-D-356): dcc-input-module.d356
Component Positions, for assembly (Pick and Place, CSV): pick_and_place.csv

Bill of Materials: multiple versions are provided optimized for various contract manufacturers:

Bill of Materials (AdvancedCircuits): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-AdvancedCircuits.csv
Bill of Materials (AllPCB): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-AllPCB.csv
Bill of Materials (Elecrow): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-Elecrow.csv
Bill of Materials (Eurocircuits): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-Eurocircuits.csv
Bill of Materials (Flux): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-Flux.csv
Bill of Materials (JLCPCB): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-JLCPCB.csv
Bill of Materials (PCBWay): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-PCBWay.csv
Bill of Materials (Seeed): BOM/dvescovi1-dcc-input-module-BOM-V277265e8-Seeed.csv
Fabrication drawing (PDF): fabrication-drawing.pdf

