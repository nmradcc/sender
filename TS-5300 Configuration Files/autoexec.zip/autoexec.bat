path=a:\;a:\util;a:\dos;a:\ethernet;c:\send;c:\bin
set DIRCMD=/ogn
echo off
echo load packet driver for eth0
epktisa 0x60

echo rem run test program if JP5 is installed
command /c jp5.bat

rem uncomment rs485.bat to enable RS-485 and/or automatic half duplex
rem rs485.bat

echo Change to C:\RESULTS
C:
cd \RESULTS
echo Technologic Systems web site is: (www.embeddedx86.com)
echo File System Version 1.00
